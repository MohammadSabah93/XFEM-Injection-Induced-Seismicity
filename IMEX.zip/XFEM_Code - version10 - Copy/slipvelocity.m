thr = 0.6;                % your threshold
mask = Vs > thr;           % logical matrix
firstCol = find(any(mask, 1), 1, 'first');   % [] if never exceeds

if isempty(firstCol)
    disp('No exceedance.');
else
    fprintf('First exceedance at column %d\n', firstCol);
end