%% --- Inertia & wave-resolution report (no loading; uses workspace vars) ---
% Requirements already in workspace (by name):
% node_coordinates [nNodes x 2], connectivity [nElem x nPerEl], elementType ('QUAD4'|'TRI3')
% params with either (cp, cs, rho) OR (E, nu, rho).  TimestepSize [Nt x 1]
% Optional: Vs [nInterfaceElem x Nt] to identify "event window" (any elem Vs > 1e-4 m/s)

fprintf('\n=== Wave Resolution Report ===\n');

%% 1) Wave speeds (use params.cp/cs if provided, else compute from E,nu,rho)
rho = params.rho_m;
have_cp = isfield(params,'cp');
have_cs = isfield(params,'cs');

if have_cp && have_cs
    cp = params.cp; cs = params.cs;
else
    % derive from isotropic linear elasticity (3D formulas)
    if ~isfield(params,'E') || ~isfield(params,'nu')
        error('Need params.cp/cs or params.E/params.nu in params.');
    end
    E  = params.Yu; nu = params.nu;
    mu = E/(2*(1+nu));                 % shear modulus
    lam = E*nu/((1+nu)*(1-2*nu));      % Lamé lambda
    cp = sqrt((lam + 2*mu)/rho);
    cs = sqrt(mu/rho);
end

fprintf('Material: rho = %.3g kg/m^3, cp = %.3f m/s, cs = %.3f m/s\n', rho, cp, cs);

%% 2) Mesh characteristic sizes
XY = node_coordinates;
conn = connectivity;

% edge lengths per element
switch upper(elementType)
    case 'QUAD4'
        ePairs = [1 2; 2 3; 3 4; 4 1];
    case 'TRI3'
        ePairs = [1 2; 2 3; 3 1];
    otherwise
        error('Unsupported elementType: %s', elementType);
end

nE = size(conn,1);
edges_per_el = size(ePairs,1);
h_elem = zeros(nE,1);
h_min_elem = zeros(nE,1);

for e = 1:nE
    nodes = conn(e,:);
    P = XY(nodes,:);
    % compute all edges
    el_edges = zeros(edges_per_el,1);
    for k = 1:edges_per_el
        i = ePairs(k,1); j = ePairs(k,2);
        el_edges(k) = hypot(P(j,1)-P(i,1), P(j,2)-P(i,2));
    end
    h_elem(e)    = mean(el_edges);  % characteristic size
    h_min_elem(e)= min(el_edges);   % tightest edge
end

h_avg = mean(h_elem);
h_min = min(h_min_elem);
h_max = max(h_elem);

fprintf('Mesh size stats (characteristic edge length):\n');
fprintf('  h_min = %.4g m, h_avg = %.4g m, h_max = %.4g m\n', h_min, h_avg, h_max);

%% 3) Time-step metrics
if ~exist('TimestepSize','var') || isempty(TimestepSize)
    error('TimestepSize vector not found in workspace.');
end
dt_all = TimestepSize(:);
dt_all = dt_all(dt_all>0 & isfinite(dt_all));

dt_min = min(dt_all);
dt_med = median(dt_all);
dt_max = max(dt_all);

fprintf('Time-step stats:\n');
fprintf('  dt_min = %.3g s, dt_med = %.3g s, dt_max = %.3g s\n', dt_min, dt_med, dt_max);

% Optional event window (if Vs exists): restrict to steps where any Vs > 1e-4
have_Vs = exist('Vs','var')==1 && ~isempty(Vs);
if have_Vs
    Vs_max_t = max(Vs,[],1);                 % 1 x Nt
    event_mask = Vs_max_t(:) > 1e-4;
    if any(event_mask)
        dt_event = TimestepSize(event_mask);
        dt_event = dt_event(dt_event>0 & isfinite(dt_event));
        if ~isempty(dt_event)
            dt_min_ev = min(dt_event); dt_med_ev = median(dt_event);
            fprintf('Event-window steps (max Vs > 1e-4 m/s):\n');
            fprintf('  dt_min_ev = %.3g s, dt_med_ev = %.3g s\n', dt_min_ev, dt_med_ev);
        end
    end
end


%% Accuracy-based f_max (spatial + temporal), more realistic than 0.8*Nyquist
PPW_target = 12;   % elements-per-wavelength target (≈10–12 for linear; ≈6–8 for quadratic)
SPP_target = 20;   % time samples per period target (≈10–20; use 20 for safety)

% Temporal accuracy limit
f_temporal = 1 / (SPP_target * dt_min);

% Spatial accuracy limits (use h_min; S-wave is typically most restrictive)
f_spatial_p = cp / (PPW_target * h_min);
f_spatial_s = cs / (PPW_target * h_min);

% Usable frequency caps
f_max_p = min(f_temporal, f_spatial_p);
f_max_s = min(f_temporal, f_spatial_s);

% Corresponding wavelengths and achieved PPW at h_min and h_avg
lambda_p = cp / f_max_p;        lambda_s = cs / f_max_s;
PPW_p_min = lambda_p / h_min;   PPW_p_avg = lambda_p / h_avg;
PPW_s_min = lambda_s / h_min;   PPW_s_avg = lambda_s / h_avg;

fprintf('Accuracy-based frequency caps:\n');
fprintf('  f_max_p = %.3g Hz (min of temporal %.3g, spatial %.3g)\n', f_max_p, f_temporal, f_spatial_p);
fprintf('  f_max_s = %.3g Hz (min of temporal %.3g, spatial %.3g)\n', f_max_s, f_temporal, f_spatial_s);
fprintf('Wavelengths at caps: lambda_p = %.3g m, lambda_s = %.3g m\n', lambda_p, lambda_s);
fprintf('PPW at caps (using h_min / h_avg):\n');
fprintf('  P-wave: PPW_min = %.2f, PPW_avg = %.2f\n', PPW_p_min, PPW_p_avg);
fprintf('  S-wave: PPW_min = %.2f, PPW_avg = %.2f\n', PPW_s_min, PPW_s_avg);

%% 5) CFL-like numbers (use smallest h and dt_min)
CFL_p = cp*dt_min / h_min;
CFL_s = cs*dt_min / h_min;
fprintf('CFL-like ratios (using h_min, dt_min):\n');
fprintf('  CFL_p = cp*dt_min/h_min = %.3g\n', CFL_p);
fprintf('  CFL_s = cs*dt_min/h_min = %.3g\n', CFL_s);
fprintf('  (For explicit schemes CFL<~0.5 is typical; implicit schemes are unconditionally stable but large values may add dispersion.)\n');

%% 6) Compact table
hdr = sprintf(['\n%-10s %-10s %-10s %-10s %-10s %-10s %-10s %-10s\n' ...
               '---------- ---------- ---------- ---------- ---------- ---------- ---------- ----------\n'], ...
              'cp(m/s)','cs(m/s)','h_min(m)','h_avg(m)','dt_min(s)','PPW_s(min)','PPW_s(avg)','PPW_p(avg)');
row = sprintf('%-10.3f %-10.3f %-10.3g %-10.3g %-10.3g %-10.2f %-10.2f %-10.2f\n', ...
              cp, cs, h_min, h_avg, dt_min, PPW_s_min, PPW_s_avg, PPW_p_avg);
fprintf('%s%s\n', hdr, row);

fprintf('=== End of Wave Resolution Report ===\n\n');
