nElem = size(interface_elements,1);
center_rel = zeros(nElem,2);

% global first node of the fracture
firstNodeID = interface_elements(1,1);
x0 = interface_nodes(firstNodeID,1);
y0 = interface_nodes(firstNodeID,2);
% x0 = 0;
% y0 = 0;
for e = 1:nElem
    n1 = interface_elements(e,1);
    n2 = interface_elements(e,2);

    x1 = interface_nodes(n1,1);
    y1 = interface_nodes(n1,2);
    x2 = interface_nodes(n2,1);
    y2 = interface_nodes(n2,2);

    % midpoint of the element
    xc = (x1 + x2)/2;
    yc = (y1 + y2)/2;

    % relative to the *global first node*
    center_rel(e,1) = xc - x0;
    center_rel(e,2) = yc - y0;
end

disp(center_rel);  % each row = [Δx Δy] relative to global first node
